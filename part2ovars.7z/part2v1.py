"""
2) Напишіть клас метаклас Meta, який усім класам, для кого він буде 
метакласом, встановлює порядковий номер. Код для перевірки 
правильності рішення...
"""


class Meta(type):

    children_number = 0

    def __call__(cls, *args):
        cls.class_number = Meta.children_number
        Meta.children_number += 1
        instance = object.__new__(cls, *args)
        return instance


Meta.children_number = 0


class Cls1(metaclass=Meta):
    def __init__(self, data):
        self.data = data


class Cls2(metaclass=Meta):
    def __init__(self, data):
        self.data = data


class Cls3(metaclass=Meta):
    def __init__(self, data):
        self.data = data


print(Meta.children_number)  # 0 початковий стан


a, b = Cls1(''), Cls2('')

# 0-ве початкове використання Meta для Cls1 примірника a:
print('a=(Cls1)=', a.class_number)

# 1-е використання Meta для Cls2 примірника b
print('b=(Cls2)=', b.class_number)

c = Cls1('')

# 2-ге використання Meta для Cls1 примірника c
print('c=(Cls1)=', c.class_number)

# 2-ге використання Meta для Cls1 (у примірнику a)
print('a=(Cls1)=', a.class_number)

# 2 останній номер використання Meta для Cls1 при створенні примірників класу:
print('Cls1=', Cls1.class_number)

# 1 останній номер використання Meta для Cls1 при створенні примірників класу:
print('Cls2=', Cls2.class_number)

d = Cls3('')

# 3-є  використання Meta для Cls3 (gпри створенні примірника d)
print('Cls3=', Cls3.class_number)

# 3-є  використання Meta для Cls3 (у примірнику d)
print('d=(Cls3)=', d.class_number)

# 2-ге використання Meta для Cls1 (у примірнику a)
print('a=(Cls1)=', a.class_number)

# 1-е використання Meta для Cls2 примірника b
print('b=(Cls2)=', b.class_number)

assert (a.class_number, b.class_number) == (2, 1)
