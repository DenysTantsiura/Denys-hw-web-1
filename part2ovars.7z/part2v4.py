"""
2) Напишіть клас метаклас Meta, який усім класам, для кого він буде 
метакласом, встановлює порядковий номер. Код для перевірки 
правильності рішення...
"""


class Meta(type):

    # children_number = 0

    def __new__(cls, *args):
        cls.class_number = Meta.children_number
        return type.__new__(cls, *args)

    def __init__(cls, *args):
        super().__init__(cls)
        cls.class_number = Meta.children_number
        Meta.children_number += 1

    def __call__(cls, *args):
        instance = object.__new__(cls, *args)
        return instance


Meta.children_number = 0


class Cls1(metaclass=Meta):
    def __init__(self, data):
        self.data = data


class Cls2(metaclass=Meta):
    def __init__(self, data):
        self.data = data


class Cls3(metaclass=Meta):
    def __init__(self, data):
        self.data = data


# 3 наступний номер після створення (оголошення) класів що наслідуються від метакласу:
print(Meta.children_number)

print('Cls1=', Cls1.class_number)
print('Cls2=', Cls2.class_number)
print('Cls3=', Cls3.class_number)

assert (Cls1.class_number, Cls2.class_number) == (0, 1)
a, b = Cls1(''), Cls2('')
assert (a.class_number, b.class_number) == (0, 1)
c, d = Cls1(''), Cls3('')

print('Cls1=', Cls1.class_number)
print('Cls2=', Cls2.class_number)
print('Cls3=', Cls3.class_number)

print('a=(Cls1)=', a.class_number)
print('b=(Cls2)=', b.class_number)
print('c=(Cls1)=', c.class_number)
print('d=(Cls3)=', d.class_number)
